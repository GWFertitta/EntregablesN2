Recordar compilar con "make" desde dentro esta misma carpeta, no usan nada del
CIAA-Firmware.

Este ejemplo convierte a la EDU-CIAA en un teclado USB.

Con las teclas de la EDU-CIAA-NXP TEC1 a TEC3 escribe "c", "i", "a" 
respectivamente. Con TEC4 "Enter". 
El LEDB indica el estado del "Num Lock".