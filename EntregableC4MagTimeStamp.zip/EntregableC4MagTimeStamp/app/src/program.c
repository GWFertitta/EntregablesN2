/*============================================================================
 * Licencia:
 * Autor:Walter Guillermo Fertitta
 * Fecha:5/12/17
 
 hice lo que pude, muestra bien los datos del magnet�metro por la uart
 pero no graba los timestamp en la memoria sd 
 Hace un monton de errores de compilacion
 
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

//#include "program.h"   // <= su propio archivo de cabecera (opcional)
#include "sapi.h"        // <= Biblioteca sAPI

#include <math.h>       // <= Funciones matematicas

#include "ff.h"       // <= Biblioteca FAT FS

//#include "c_i18n_es.h" // <= para traducir el codigo C al espa�ol (opcional)
//#include "c_i18n_es.h" // <= para traducir la sAPI al espa�ol (opcional)

/*==================[definiciones y macros]==================================*/
#define ADDRESS_MAG  0x0D  //direccion magnetometro

#define FILENAME "MAGconTimestamp.txt"
#define MAX_BYTES_TO_SAVE       100
#define BYTES_OF_INFORMATION    35
/*==================[definiciones de datos internos]=========================*/

/* Buffer */
static char uartBuff[10];

CONSOLE_PRINT_ENABLE

static FATFS fs;           // <-- FatFs work area needed for each volume
static FIL fp;             // <-- File object needed for each open file

// Arreglo donde se almacena la hora y fecha
static char     infoToSave [BYTES_OF_INFORMATION];

//uint32_t  nbytes;

UINT nbytes;





/*==================[definiciones de datos externos]=========================*/
uint8_t bufferTransmision[2];
uint8_t registroAleer;

int16_t xValue;
int16_t yValue;
int16_t zValue;

uint8_t x_MSB, x_LSB;
uint8_t y_MSB, y_LSB;
uint8_t z_MSB, z_LSB;

/*==================[declaraciones de funciones internas]====================*/

// Funcion para formatear la salida con fecha, hora y el valor de los ejes del magnetometro x, y, z.
void        formatInfoToSave( rtc_t * rtc );

/**
 * C++ version 0.4 char* style "itoa":
 * Written by Luk�s Chmela
 * Released under GPLv3.
 */
char* itoa(int value, char* result, int base);

/* Enviar fecha y hora en formato "DD/MM/YYYY, HH:MM:SS" */
void showDateAndTime( rtc_t * rtc );

/*==================[declaraciones de funciones externas]====================*/



/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main( void ){

   // ---------- CONFIGURACIONES ------------------------------

   // Inicializar y configurar la plataforma
   boardConfig();

   // Inicializar UART_USB como salida de consola
   consolePrintConfigUart( UART_USB, 115200 );

   // Inicializar QMC5883L
   i2cConfig(I2C0, 100000);
   
   bufferTransmision[0] = 0x0B;  //registro a escribir 0x0B
   bufferTransmision[1] = 1;  //valor a escribir en registro (set/reset period)
   i2cWrite( I2C0, ADDRESS_MAG, bufferTransmision, 2, TRUE );  //escribe en registro
   
   
   bufferTransmision[0] = 0x09;  //registro a escribir 0x09
   bufferTransmision[1] = 0x11;  //valor a escribir en registro
                                 //over sample ratio 512
                                 //scale 8 gauss
                                 //output data rate 10Hz
                                 //mode continuous
   i2cWrite( I2C0, ADDRESS_MAG, bufferTransmision, 2, TRUE );  //escribe en registro
   
   
   delay_t miDalay;

   delayConfig( &miDalay, 200 );
   
    // Estructura RTC
   rtc_t rtc;

   rtc.year = 2017;
   rtc.month = 12;
   rtc.mday = 8;
   rtc.wday = 1;
   rtc.hour = 18;
   rtc.min = 50;
   rtc.sec= 0;

   bool_t val = 0;
   uint8_t i = 0;

   // Inicializar RTC
   val = rtcConfig( &rtc );
   
   // Da un area de trabajo en el SD
   if( f_mount( &fs, "", 0 ) != FR_OK ){
      // If this fails, it means that the function could
      // not register a file system object.
      // Check whether the SD card is correctly connected
   }


   // ---------- REPETIR POR SIEMPRE --------------------------
   while( TRUE )
   {
	   if( delayRead( &miDalay ) ){
           
           registroAleer = 0;   //registro X LSB
      i2cRead( I2C0, ADDRESS_MAG, &registroAleer, 1, TRUE, &x_LSB, 1, TRUE);  //leo valor
      
      registroAleer = 1;   //registro X MSB
      i2cRead( I2C0, ADDRESS_MAG, &registroAleer, 1, TRUE, &x_MSB, 1, TRUE);  //leo valor
      
      registroAleer = 2;   //registro Y LSB
      i2cRead( I2C0, ADDRESS_MAG, &registroAleer, 1, TRUE, &y_LSB, 1, TRUE);  //leo valor
      
      registroAleer = 3;   //registro Y MSB
      i2cRead( I2C0, ADDRESS_MAG, &registroAleer, 1, TRUE, &y_MSB, 1, TRUE);  //leo valor
      
      registroAleer = 4;   //registro Z LSB
      i2cRead( I2C0, ADDRESS_MAG, &registroAleer, 1, TRUE, &z_LSB, 1, TRUE);  //leo valor
      
      registroAleer = 5;   //registro Z MSB
      i2cRead( I2C0, ADDRESS_MAG, &registroAleer, 1, TRUE, &z_MSB, 1, TRUE);  //leo valor

      
      xValue = x_MSB;
      xValue = (xValue << 8)|x_LSB;
      
      yValue = y_MSB;
      yValue = (yValue << 8)|x_LSB;
      
      zValue = z_MSB;
      zValue = (zValue << 8)|z_LSB;

         
         
         // Se debe esperar minimo 67ms entre lecturas su la tasa es de 15Hz
         // para leer un nuevo valor del magnet�metro
         delay(5000);
         
    
         
       
           consolePrintInt( xValue );
            uartWriteString( UART_USB, ",");
           consolePrintInt(  yValue);
            uartWriteString( UART_USB, ",");
           consolePrintInt( zValue);
            uartWriteString( UART_USB, ",");
                 // Leer fecha y hora
      val = rtcRead( &rtc );
      // Mostrar fecha y hora en formato "DD/MM/YYYY, HH:MM:SS"
      showDateAndTime( &rtc );
         uartWriteString( UART_USB, "\r\n");
         uartWriteString( UART_USB, "\r\n");
         
       // Formatea la salida y la guarda en el arreglo global informationToSave.
       // Formato: DD/MM/YYYY_HH:MM:SS_XXX;YYY;ZZZ;
        formatInfoToSave( &rtc );  
         
        // Crea/abre un archivo, luego escribe un string y lo cierra
   if( f_open( &fp, FILENAME, FA_WRITE | FA_CREATE_ALWAYS ) == FR_OK ){
      f_write( &fp, infoToSave, MAX_BYTES_TO_SAVE, &nbytes );

      f_close(&fp);
         
      }
   } 

   // NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa se ejecuta 
   // directamenteno sobre un microcontroladore y no es llamado/ por ningun
   // Sistema Operativo, como en el caso de un programa para PC.
   return 0;
}

/*==================[definiciones de funciones internas]=====================*/

// Formatea el arreglo a guardar con DD/MM/YYYY_HH:MM:SS_XXX;YYY;ZZZ;
void        formatInfoToSave ( rtc_t * rtc ){
    infoToSave[0]  = (rtc->mday/10) + '0';
    infoToSave[1]  = (rtc->mday%10) + '0';
    infoToSave[2]  = '/';
    infoToSave[3]  = (rtc->month/10) + '0';
    infoToSave[4]  = (rtc->month%10) + '0';
    infoToSave[5]  = '/';
    infoToSave[6]  = (rtc->year/1000) + '0';
    infoToSave[7]  = ((rtc->year%1000)/100) + '0';
    infoToSave[8]  = ((rtc->year%100)/10) + '0';
    infoToSave[9]  = (rtc->year%10) + '0';
    infoToSave[10] = '_';
    infoToSave[11] = (rtc->hour/10) + '0';
    infoToSave[12] = (rtc->hour%10) + '0';
    infoToSave[13] = ':';
    infoToSave[14] = (rtc->min/10) + '0';
    infoToSave[15] = (rtc->min%10) + '0';
    infoToSave[16] = ':';
    infoToSave[17] = (rtc->sec/10) + '0';
    infoToSave[18] = (rtc->sec%10) + '0';
    infoToSave[19] = '_';
    infoToSave[20] = (uint8_t)(xValue/100) + '0';
    infoToSave[21] = (uint8_t)(xValue%100)/10 + '0';
    infoToSave[22] = (uint8_t)(xValue%10) + '0';
    infoToSave[23] = ';';
    infoToSave[24] = (uint8_t)(yValue/100) + '0';
    infoToSave[25] = (uint8_t)(yValue%100)/10 + '0';
    infoToSave[26] = (uint8_t)(yValue%10) + '0';
    infoToSave[27] = ';';
    infoToSave[28] = (uint8_t)(zValue/100) + '0';
    infoToSave[29] = (uint8_t)(zValue%100)/10 + '0';
    infoToSave[30] = (uint8_t)(zValue%10) + '0';
    infoToSave[31] = ';';
    infoToSave[32] = '\n';
    infoToSave[33] = '\r';
    infoToSave[34] = '\0';
}

/**
 * C++ version 0.4 char* style "itoa":
 * Written by Luk�s Chmela
 * Released under GPLv3.
 */
char* itoa(int value, char* result, int base) {
   // check that the base if valid
   if (base < 2 || base > 36) { *result = '\0'; return result; }

   char* ptr = result, *ptr1 = result, tmp_char;
   int tmp_value;

   do {
      tmp_value = value;
      value /= base;
      *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
   } while ( value );

   // Apply negative sign
   if (tmp_value < 0) *ptr++ = '-';
   *ptr-- = '\0';
   while(ptr1 < ptr) {
      tmp_char = *ptr;
      *ptr--= *ptr1;
      *ptr1++ = tmp_char;
   }
   return result;
}

/* Enviar fecha y hora en formato "DD/MM/YYYY, HH:MM:SS" */
void showDateAndTime( rtc_t * rtc ){
   /* Conversion de entero a ascii con base decimal */
   itoa( (int) (rtc->mday), (char*)uartBuff, 10 ); /* 10 significa decimal */
   /* Envio el dia */
   if( (rtc->mday)<10 )
      uartWriteByte( UART_USB, '0' );
   uartWriteString( UART_USB, uartBuff );
   uartWriteByte( UART_USB, '/' );

   /* Conversion de entero a ascii con base decimal */
   itoa( (int) (rtc->month), (char*)uartBuff, 10 ); /* 10 significa decimal */
   /* Envio el mes */
   if( (rtc->month)<10 )
      uartWriteByte( UART_USB, '0' );
   uartWriteString( UART_USB, uartBuff );
   uartWriteByte( UART_USB, '/' );

   /* Conversion de entero a ascii con base decimal */
   itoa( (int) (rtc->year), (char*)uartBuff, 10 ); /* 10 significa decimal */
   /* Envio el a�o */
   if( (rtc->year)<10 )
      uartWriteByte( UART_USB, '0' );
   uartWriteString( UART_USB, uartBuff );

   uartWriteString( UART_USB, ", ");

   /* Conversion de entero a ascii con base decimal */
   itoa( (int) (rtc->hour), (char*)uartBuff, 10 ); /* 10 significa decimal */
   /* Envio la hora */
   if( (rtc->hour)<10 )
      uartWriteByte( UART_USB, '0' );
   uartWriteString( UART_USB, uartBuff );
   uartWriteByte( UART_USB, ':' );

   /* Conversion de entero a ascii con base decimal */
   itoa( (int) (rtc->min), (char*)uartBuff, 10 ); /* 10 significa decimal */
   /* Envio los minutos */
   // uartBuff[2] = 0;    /* NULL */
   if( (rtc->min)<10 )
      uartWriteByte( UART_USB, '0' );
   uartWriteString( UART_USB, uartBuff );
   uartWriteByte( UART_USB, ':' );

   /* Conversion de entero a ascii con base decimal */
   itoa( (int) (rtc->sec), (char*)uartBuff, 10 ); /* 10 significa decimal */
   /* Envio los segundos */
   if( (rtc->sec)<10 )
      uartWriteByte( UART_USB, '0' );
   uartWriteString( UART_USB, uartBuff );

   /* Envio un 'enter' */
   uartWriteString( UART_USB, "\r\n");
}

/*==================[definiciones de funciones externas]=====================*/



}/*==================[fin del archivo]========================================*/